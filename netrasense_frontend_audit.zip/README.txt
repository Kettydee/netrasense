NetraSense Frontend Audit Bundle
Created: Sat Oct 24 20:44:29 IST 2026
Branch: main
Commit: 0b22525b3abb13f03ebc35f0637fa95dab531ad5

Included files:
README.txt
src/lib/webSerial.ts
src/lib/sensor.ts
src/routes/_authenticated/dashboard.tsx
